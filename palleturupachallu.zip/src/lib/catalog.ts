import catVeg from "@/assets/cat-veg.jpg";
import catNonveg from "@/assets/cat-nonveg.jpg";
import catKaram from "@/assets/cat-karam.jpg";
import catSnacks from "@/assets/cat-snacks.jpg";
import tomato from "@/assets/p-tomato.jpg";
import avakaya from "@/assets/p-avakaya.jpg";
import chinthakay from "@/assets/p-chinthakay.jpg";
import mirchi from "@/assets/p-mirchi.jpg";
import gongura from "@/assets/p-gongura.jpg";
import chicken from "@/assets/p-chicken.jpg";
import mutton from "@/assets/p-mutton.jpg";
import fish from "@/assets/p-fish.jpg";
import prawns from "@/assets/p-prawns.jpg";
import munagaku from "@/assets/p-munagaku.jpg";
import kobbari from "@/assets/p-kobbari.jpg";
import avisa from "@/assets/p-avisa.jpg";
import putnala from "@/assets/p-putnala.jpg";
import karivepaku from "@/assets/p-karivepaku.jpg";
import karapoosa from "@/assets/p-karapoosa.jpg";
import boorelu from "@/assets/p-boorelu.jpg";
import ariselu from "@/assets/p-ariselu.jpg";

export const WHATSAPP_NUMBER = "916303444866";
export const WHATSAPP_DISPLAY = "6303444866";
export const GENERAL_MESSAGE =
  "Namaste Palleturu Pachallu! I would like to know more about your homemade pickles, karam varieties, and snacks. Please share the available products and prices.";

export const MAPS_URL = "https://maps.app.goo.gl/mtxfrihCuZu6JSHe8";

export const ADDRESS = {
  lines: ["Chinthamotu Village", "Bhattiprolu Mandal", "Bapatla District, Andhra Pradesh 522257"],
  full: "Chinthamotu Village, Bhattiprolu Mandal, Bapatla District, Andhra Pradesh 522257",
};

export const SOCIAL = {
  instagram: "https://www.instagram.com/kotithefamilyman?exln=MWdoeWJhMHNucm12Yg==",
  facebook: "https://www.facebook.com/share/1PYczvSanJ/",
  youtube: "https://www.youtube.com/@Allinonekoti1989",
};

export function whatsappLink(message: string = GENERAL_MESSAGE) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

export function productMessage(name: string) {
  return `Namaste Palleturu Pachallu! I am interested in purchasing ${name}. Please share the price, available pack sizes, and ordering details.`;
}

export type CategoryId = "veg" | "nonveg" | "karam" | "snacks";

export const categories: {
  id: CategoryId;
  title: string;
  short: string;
  description: string;
  image: string;
}[] = [
  { id: "veg", title: "Vegetarian Pickles", short: "Veg Pickles", image: catVeg,
    description: "Bold, tangy, and flavourful Andhra pickles made to bring an authentic taste to your meals." },
  { id: "nonveg", title: "Non-Vegetarian Pickles", short: "Non-Veg Pickles", image: catNonveg,
    description: "Rich, spicy, savoury pickle varieties inspired by the bold flavours of Andhra cuisine." },
  { id: "karam", title: "Karam & Powders", short: "Karam & Powders", image: catKaram,
    description: "Traditional Andhra spice blends and karam varieties that add a distinctive touch to everyday meals." },
  { id: "snacks", title: "Traditional Snacks", short: "Traditional Snacks", image: catSnacks,
    description: "Celebrate the joy of traditional Andhra snacks, with familiar flavours for tea-time treats and special occasions." },
];

export type Product = {
  id: string;
  name: string;
  subtitle?: string;
  telugu?: boolean;
  category: CategoryId;
  description: string;
  image: string;
};

export const products: Product[] = [
  { id: "tomato", category: "veg", name: "Tomato Pickle", image: tomato, description: "A tangy, spicy tomato pickle inspired by traditional Andhra flavours." },
  { id: "avakaya", category: "veg", name: "Avakaya Pickle", image: avakaya, description: "A classic Andhra mango pickle known for its bold, spicy, and tangy character." },
  { id: "chinthakay", category: "veg", name: "Chinthakay Pickle", image: chinthakay, description: "A traditional tamarind-based pickle with a distinctive tangy flavour." },
  { id: "pandu-mirchi", category: "veg", name: "Pandu Mirchi Pickle", image: mirchi, description: "A vibrant red chilli pickle inspired by the bold flavours of Andhra cuisine." },
  { id: "gongura", category: "veg", name: "Gongura Pickle", image: gongura, description: "A much-loved Andhra pickle inspired by the distinctive tang of gongura leaves." },
  { id: "chicken", category: "nonveg", name: "Chicken Pickle", image: chicken, description: "A bold, spicy chicken pickle inspired by traditional Andhra non-vegetarian flavours." },
  { id: "mutton", category: "nonveg", name: "Mutton Pickle", image: mutton, description: "A rich and flavourful mutton pickle inspired by Andhra's love for bold, savoury tastes." },
  { id: "fish", category: "nonveg", name: "Fish Pickle", image: fish, description: "A distinctive fish pickle inspired by traditional Andhra spice combinations." },
  { id: "prawns", category: "nonveg", name: "Prawns Pickle", image: prawns, description: "A flavourful prawn pickle featuring the bold character of Andhra-style spices." },
  { id: "munagaku", category: "karam", telugu: true, name: "మునగాకు కారం", subtitle: "Drumstick Leaf Karam", image: munagaku, description: "A traditional karam variety inspired by the distinctive flavour of drumstick leaves." },
  { id: "kobbari", category: "karam", telugu: true, name: "కొబ్బరి కారం", subtitle: "Coconut Karam", image: kobbari, description: "A traditional coconut-based karam variety for adding a distinctive flavour to everyday meals." },
  { id: "avisa", category: "karam", telugu: true, name: "అవిశ గింజల కారం", subtitle: "Flaxseed Karam", image: avisa, description: "A traditional-style karam blend featuring flaxseeds and aromatic spices." },
  { id: "putnala", category: "karam", telugu: true, name: "పుట్నాల పొడి", subtitle: "Roasted Gram Powder", image: putnala, description: "A familiar traditional Andhra powder made with roasted gram as its central ingredient." },
  { id: "karivepaku", category: "karam", telugu: true, name: "కరివేపాకు కారం", subtitle: "Curry Leaf Karam", image: karivepaku, description: "A traditional karam blend inspired by the distinctive aroma of curry leaves." },
  { id: "karapoosa", category: "snacks", name: "Karapoosa / Chakkaralu", image: karapoosa, description: "Traditional Andhra savoury snacks perfect for enjoying with tea or sharing with family." },
  { id: "boorelu", category: "snacks", name: "Boorelu", image: boorelu, description: "A traditional Andhra sweet snack inspired by festive and homemade flavours." },
  { id: "ariselu", category: "snacks", name: "Ariselu", image: ariselu, description: "A beloved traditional Andhra sweet known for its distinctive shape and rich, festive character." },
];

export const featuredIds = ["avakaya", "gongura", "chicken", "prawns", "karivepaku", "putnala", "karapoosa", "ariselu"];
export const popularIds = ["tomato", "mutton", "munagaku", "boorelu"];

export const categoryLabel = (id: CategoryId) => categories.find((c) => c.id === id)!.short;
