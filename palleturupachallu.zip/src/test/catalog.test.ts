import { describe, expect, it } from "vitest";
import { productMessage, products, whatsappLink } from "@/lib/catalog";

describe("catalog", () => {
  it("lists all 17 products", () => {
    expect(products).toHaveLength(17);
  });
  it("product WhatsApp link uses business number and product name", () => {
    const url = whatsappLink(productMessage("Avakaya Pickle"));
    expect(url.startsWith("https://wa.me/916303444866?text=")).toBe(true);
    expect(decodeURIComponent(url.split("text=")[1] ?? "")).toContain("Avakaya Pickle");
  });
});
