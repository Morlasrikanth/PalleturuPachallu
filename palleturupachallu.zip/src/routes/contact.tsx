import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import hero from "@/assets/hero.jpg";
import { ADDRESS, MAPS_URL, WHATSAPP_DISPLAY, products, whatsappLink } from "@/lib/catalog";
import { PageHero, SocialLinks } from "@/components/site/Layout";
import { WhatsAppIcon } from "@/components/site/Icons";
import { MapPin } from "lucide-react";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Us — Palleturu Pachallu" },
      { name: "description", content: "Enquire about Palleturu Pachallu pickles, karam and snacks on WhatsApp: 6303444866." },
      { property: "og:title", content: "Contact Us — Palleturu Pachallu" },
      { property: "og:description", content: "Let's bring the taste of Palleturu to your home." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ContactPage,
});

const input = "mt-1 w-full rounded-lg border border-input bg-card px-4 py-3 text-earth outline-none focus:border-turmeric focus:ring-2 focus:ring-ring/40";

function ContactPage() {
  const [form, setForm] = useState({ name: "", phone: "", product: "", message: "" });
  const [errors, setErrors] = useState<{ name?: string; phone?: string; message?: string }>({});

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const err: { name?: string; phone?: string; message?: string } = {};
    if (form.name.trim().length < 2) err.name = "Please enter your name.";
    if (form.phone && !/^[0-9+\s-]{10,15}$/.test(form.phone.trim())) err.phone = "Please enter a valid phone number.";
    if (form.message.trim().length < 5) err.message = "Please write a short message.";
    setErrors(err);
    if (Object.keys(err).length) return;
    const text = [
      "Namaste Palleturu Pachallu!",
      `Name: ${form.name.trim()}`,
      form.phone && `Phone: ${form.phone.trim()}`,
      form.product && `Product: ${form.product}`,
      `Message: ${form.message.trim()}`,
    ].filter(Boolean).join("\n");
    window.open(whatsappLink(text), "_blank", "noopener,noreferrer");
  };

  return (
    <>
      <PageHero eyebrow="Contact Us" title="Let's Bring the Taste of Palleturu to Your Home." image={hero} />
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-5">
        <aside className="space-y-6 lg:col-span-2">
          <div className="rounded-xl bg-earth p-8 text-primary-foreground shadow-lift">
            <h2 className="text-3xl font-bold">Palleturu Pachallu</h2>
            <p className="mt-2 text-turmeric">Amma Chethi Kammadhanam — A Touch of Unique Spices.</p>
            <p className="mt-6 text-sm text-primary-foreground/70">WhatsApp</p>
            <p className="text-2xl font-bold">{WHATSAPP_DISPLAY}</p>
            <a href={whatsappLink()} target="_blank" rel="noopener noreferrer"
              className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-whatsapp px-6 py-3.5 font-bold text-earth hover:opacity-90">
              <WhatsAppIcon className="h-5 w-5" /> Chat on WhatsApp
            </a>
            <p className="mt-8 text-sm text-primary-foreground/70">Visit our kitchen</p>
            <address className="not-italic mt-1 text-sm leading-relaxed text-primary-foreground/90">
              {ADDRESS.lines.map((line) => <span key={line} className="block">{line}</span>)}
            </address>
            <a href={MAPS_URL} target="_blank" rel="noopener noreferrer"
              className="mt-3 inline-flex items-center gap-2 text-sm font-bold text-turmeric underline decoration-dotted underline-offset-4 hover:text-primary-foreground">
              <MapPin className="h-4 w-4" /> View on Google Maps
            </a>
            <p className="mt-8 text-sm text-primary-foreground/70">Follow us</p>
            <div className="mt-3"><SocialLinks /></div>
          </div>
          <div className="kolam-bg rounded-xl p-6">
            <h3 className="text-xl font-bold text-earth">General Product Enquiries</h3>
            <p className="mt-2 text-sm text-muted-foreground">Ask us about prices, pack sizes, availability and ordering for any of our pickles, karam varieties or snacks.</p>
          </div>
        </aside>
        <form onSubmit={submit} noValidate className="rounded-xl border border-border bg-card p-6 shadow-soft sm:p-8 lg:col-span-3">
          <h2 className="text-2xl font-bold text-earth">Send an Enquiry</h2>
          <p className="mt-1 text-sm text-muted-foreground">Your details will open in WhatsApp so you can send them to us directly.</p>
          <div className="mt-6 grid gap-5 sm:grid-cols-2">
            <label className="block text-sm font-semibold text-earth">Your Name *
              <input className={input} value={form.name} maxLength={80} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              {errors.name && <span className="mt-1 block text-xs text-destructive">{errors.name}</span>}
            </label>
            <label className="block text-sm font-semibold text-earth">Phone (optional)
              <input className={input} inputMode="tel" value={form.phone} maxLength={15} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              {errors.phone && <span className="mt-1 block text-xs text-destructive">{errors.phone}</span>}
            </label>
          </div>
          <label className="mt-5 block text-sm font-semibold text-earth">Product of interest
            <select className={input} value={form.product} onChange={(e) => setForm({ ...form, product: e.target.value })}>
              <option value="">General enquiry</option>
              {products.map((p) => <option key={p.id} value={p.name}>{p.name}{p.subtitle ? ` (${p.subtitle})` : ""}</option>)}
            </select>
          </label>
          <label className="mt-5 block text-sm font-semibold text-earth">Message *
            <textarea className={input} rows={5} maxLength={600} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
            {errors.message && <span className="mt-1 block text-xs text-destructive">{errors.message}</span>}
          </label>
          <button type="submit" className="mt-6 inline-flex items-center gap-2 rounded-lg bg-primary px-7 py-3.5 font-bold text-primary-foreground hover:bg-chilli">
            <WhatsAppIcon className="h-5 w-5" /> Send via WhatsApp
          </button>
        </form>
      </div>
    </>
  );
}
