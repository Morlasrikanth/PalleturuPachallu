import { createFileRoute, Link } from "@tanstack/react-router";
import hero from "@/assets/cat-karam.jpg";
import { categories, products } from "@/lib/catalog";
import { PageHero } from "@/components/site/Layout";

export const Route = createFileRoute("/categories")({
  head: () => ({
    meta: [
      { title: "Product Categories — Palleturu Pachallu" },
      { name: "description", content: "Veg pickles, non-veg pickles, karam & powders and traditional Andhra snacks." },
      { property: "og:title", content: "Product Categories — Palleturu Pachallu" },
      { property: "og:description", content: "Explore four collections of authentic Andhra flavours." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CategoriesPage,
});

function CategoriesPage() {
  return (
    <>
      <PageHero eyebrow="Collections" title="Product Categories" image={hero}
        subtitle="Four collections, one taste of home." />
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-16 sm:px-6 md:grid-cols-2">
        {categories.map((c) => (
          <article key={c.id} className="group overflow-hidden rounded-xl border border-border bg-card shadow-soft transition hover:shadow-lift">
            <div className="aspect-[16/10] overflow-hidden">
              <img src={c.image} alt={c.title} loading="lazy" width={1024} height={1024}
                className="h-full w-full object-cover transition duration-700 group-hover:scale-105" />
            </div>
            <div className="p-6 sm:p-8">
              <p className="text-xs font-bold uppercase tracking-wider text-chilli">{products.filter((p) => p.category === c.id).length} varieties</p>
              <h2 className="mt-1 text-3xl font-bold text-earth">{c.title}</h2>
              <p className="mt-3 text-muted-foreground">{c.description}</p>
              <Link to="/products" search={{ category: c.id }}
                className="mt-6 inline-flex rounded-lg bg-primary px-6 py-3 font-bold text-primary-foreground hover:bg-chilli">
                Explore Products
              </Link>
            </div>
          </article>
        ))}
      </div>
    </>
  );
}
