import { createFileRoute, Link } from "@tanstack/react-router";
import hero from "@/assets/cat-veg.jpg";
import { categories, products, type CategoryId } from "@/lib/catalog";
import { ProductCard } from "@/components/site/ProductCard";
import { PageHero } from "@/components/site/Layout";

const ids = ["veg", "nonveg", "karam", "snacks"] as const;

export const Route = createFileRoute("/products")({
  validateSearch: (s: Record<string, unknown>): { category?: CategoryId | undefined } => ({
    category: ids.includes(s["category"] as CategoryId) ? (s["category"] as CategoryId) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "All Products — Palleturu Pachallu" },
      { name: "description", content: "Browse all Andhra veg pickles, non-veg pickles, karam powders and traditional snacks. Buy on WhatsApp." },
      { property: "og:title", content: "All Products — Palleturu Pachallu" },
      { property: "og:description", content: "Every pickle, karam and snack from Palleturu Pachallu, with direct WhatsApp ordering." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProductsPage,
});

function ProductsPage() {
  const { category } = Route.useSearch();
  const shown = categories.filter((c) => !category || c.id === category);
  const tabs = [{ id: undefined, label: "All Products" }, ...categories.map((c) => ({ id: c.id, label: c.short }))];

  return (
    <>
      <PageHero eyebrow="Our Collection" title="All Products" image={hero}
        subtitle="Pickles, karam varieties and snacks inspired by the flavours of Palleturu." />
      <div className="sticky top-[73px] z-30 border-b border-border bg-cream/95 backdrop-blur sm:top-[89px]">
        <div className="mx-auto flex max-w-7xl gap-2 overflow-x-auto px-4 py-3 sm:px-6">
          {tabs.map((t) => {
            const active = t.id === category;
            return (
              <Link key={t.label} to="/products" search={t.id ? { category: t.id } : {}} resetScroll={false}
                className={`shrink-0 rounded-full border px-4 py-2 text-sm font-bold transition ${
                  active ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-earth hover:border-primary hover:text-primary"
                }`}>
                {t.label}
              </Link>
            );
          })}
        </div>
      </div>
      <div className="mx-auto max-w-7xl space-y-16 px-4 py-14 sm:px-6">
        {shown.map((c) => (
          <section key={c.id} aria-labelledby={`h-${c.id}`}>
            <div className="mb-6 flex items-end justify-between gap-4 border-b border-border pb-3">
              <div>
                <h2 id={`h-${c.id}`} className="text-3xl font-bold text-earth">{c.title}</h2>
                <p className="mt-1 text-sm text-muted-foreground">{c.description}</p>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-5 min-[420px]:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {products.filter((p) => p.category === c.id).map((p) => <ProductCard key={p.id} product={p} />)}
            </div>
          </section>
        ))}
      </div>
    </>
  );
}
