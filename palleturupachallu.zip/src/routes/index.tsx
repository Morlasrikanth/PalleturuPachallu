import { createFileRoute, Link } from "@tanstack/react-router";
import { HandHeart, Leaf, MessageCircle, UtensilsCrossed } from "lucide-react";
import hero from "@/assets/hero.jpg";
import kitchen from "@/assets/story-kitchen.jpg";
import { categories, featuredIds, popularIds, products, whatsappLink } from "@/lib/catalog";
import { ProductCard } from "@/components/site/ProductCard";
import { SectionHeading, SocialLinks } from "@/components/site/Layout";
import { WhatsAppIcon } from "@/components/site/Icons";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Palleturu Pachallu — Authentic Andhra Pickles, Karam & Snacks" },
      { name: "description", content: "Amma Chethi Kammadhanam. Traditional Andhra veg & non-veg pickles, karam powders and snacks. Order directly on WhatsApp." },
      { property: "og:title", content: "Palleturu Pachallu — Amma Chethi Kammadhanam" },
      { property: "og:description", content: "Traditional Andhra pickles, karam varieties and homemade snacks. Order on WhatsApp." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const pick = (ids: string[]) => ids.map((id) => products.find((p) => p.id === id)!);

const features = [
  { Icon: Leaf, title: "Traditional Andhra Flavours", text: "Explore flavours inspired by the food traditions of Andhra Pradesh." },
  { Icon: UtensilsCrossed, title: "A Variety for Every Table", text: "Discover vegetarian pickles, non-vegetarian pickles, karam varieties, and traditional snacks." },
  { Icon: HandHeart, title: "A Taste of Home", text: "Celebrate the familiar flavours and food memories that make every meal special." },
  { Icon: MessageCircle, title: "Easy WhatsApp Enquiries", text: "Contact us directly to ask about prices, pack sizes, availability, and ordering." },
];

function Index() {
  return (
    <>
      {/* Hero */}
      <section className="relative min-h-[85vh] overflow-hidden">
        <img src={hero} alt="Traditional Andhra pickles on a village veranda overlooking green paddy fields"
          width={1920} height={1088} fetchPriority="high"
          className="absolute inset-0 h-full w-full object-cover object-[70%_center]" />
        <div className="bg-hero-overlay absolute inset-0" />
        <div className="relative mx-auto flex min-h-[85vh] max-w-7xl items-end px-4 pb-16 pt-24 sm:px-6 md:items-center md:pb-24">
          <div className="fade-up max-w-xl text-primary-foreground">
            <p className="text-xs font-bold uppercase tracking-[0.25em] text-turmeric">Authentic Andhra Homemade Flavours</p>
            <h1 className="mt-4 text-5xl font-extrabold leading-[1.05] sm:text-6xl lg:text-7xl">Amma Chethi Kammadhanam</h1>
            <p className="mt-4 font-display text-xl italic text-turmeric sm:text-2xl">Traditional Andhra Taste, Straight from Palleturu.</p>
            <p className="mt-5 text-base leading-relaxed text-primary-foreground/85 sm:text-lg">
              Discover the unforgettable flavours of traditional Andhra pickles, aromatic karam varieties, and homemade snacks, lovingly inspired by the taste of home.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link to="/products" className="inline-flex items-center justify-center rounded-lg bg-primary px-7 py-3.5 font-bold text-primary-foreground shadow-lift transition hover:bg-chilli">
                Explore Our Products
              </Link>
              <a href={whatsappLink()} target="_blank" rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 rounded-lg border-2 border-turmeric px-7 py-3.5 font-bold text-primary-foreground transition hover:bg-turmeric hover:text-earth">
                <WhatsAppIcon className="h-5 w-5" /> Order on WhatsApp
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Intro */}
      <section className="mx-auto max-w-3xl px-4 py-20 text-center sm:px-6">
        <p className="text-xs font-bold uppercase tracking-[0.25em] text-leaf">Welcome to Palleturu Pachallu</p>
        <p className="mt-5 font-display text-2xl leading-relaxed text-earth sm:text-3xl">
          “Bringing the authentic taste of Palleturu to every home, with traditional recipes, aromatic spices, and the unforgettable goodness of <span className="text-primary">Amma Chethi Kammadhanam</span>.”
        </p>
        <div className="motif-divider mx-auto mt-8 w-48" />
      </section>

      {/* Categories */}
      <section className="kolam-bg py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <SectionHeading eyebrow="Our Collections" title="Discover the Taste of Palleturu"
            subtitle="From traditional pickles to irresistible snacks, explore flavours inspired by Andhra's rich food heritage." />
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {categories.map((c) => (
              <Link key={c.id} to="/products" search={{ category: c.id }}
                className="group relative aspect-[3/4] overflow-hidden rounded-xl shadow-soft transition hover:-translate-y-1 hover:shadow-lift">
                <img src={c.image} alt={c.title} loading="lazy" width={1024} height={1024}
                  className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-110" />
                <div className="bg-card-overlay absolute inset-0" />
                <div className="absolute inset-x-0 bottom-0 p-5 text-primary-foreground">
                  <h3 className="text-2xl font-bold">{c.short}</h3>
                  <p className="mt-2 text-sm text-primary-foreground/85">{c.description}</p>
                  <span className="mt-4 inline-block rounded-md bg-turmeric px-4 py-2 text-xs font-bold uppercase tracking-wider text-earth">Explore Collection</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <SectionHeading eyebrow="Featured" title="Flavours Everyone Will Love" />
        <div className="mt-12 grid grid-cols-1 gap-5 min-[420px]:grid-cols-2 lg:grid-cols-4">
          {pick(featuredIds).map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
        <div className="mt-10 text-center">
          <Link to="/products" className="inline-flex rounded-lg bg-primary px-7 py-3 font-bold text-primary-foreground hover:bg-chilli">Explore All Products</Link>
        </div>
      </section>

      {/* Why choose */}
      <section className="bg-leaf py-20 text-primary-foreground">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="text-center">
            <p className="text-xs font-bold uppercase tracking-[0.25em] text-turmeric">Why Us</p>
            <h2 className="mt-2 text-3xl font-bold sm:text-4xl">Why Choose Palleturu Pachallu?</h2>
          </div>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {features.map(({ Icon, title, text }) => (
              <div key={title} className="rounded-xl border border-primary-foreground/15 bg-primary-foreground/5 p-6">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-turmeric text-earth"><Icon className="h-6 w-6" /></div>
                <h3 className="mt-5 text-xl font-bold">{title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-primary-foreground/80">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Brand story */}
      <section className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-20 sm:px-6 lg:grid-cols-2">
        <div className="relative">
          <img src={kitchen} alt="A traditional Andhra village kitchen with clay pots and drying red chillies" loading="lazy"
            width={1280} height={960} className="rounded-xl object-cover shadow-lift" />
          <div className="absolute -bottom-6 -right-4 hidden rounded-xl bg-primary px-6 py-4 text-primary-foreground shadow-lift sm:block">
            <p className="font-telugu text-xl font-bold">అమ్మచేతి కమ్మదనం</p>
          </div>
        </div>
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.25em] text-chilli">Our Heart</p>
          <h2 className="mt-2 text-4xl font-bold text-earth sm:text-5xl">Amma Chethi Kammadhanam</h2>
          <p className="mt-3 font-display text-xl italic text-leaf">A Touch of Unique Spices.</p>
          <div className="mt-6 space-y-4 leading-relaxed text-muted-foreground">
            <p>Some flavours are more than food. They are memories of home, family meals, village kitchens, and the comforting taste of something made with love.</p>
            <p>Palleturu Pachallu celebrates these timeless traditions through a collection of Andhra-inspired pickles, karam varieties, and snacks.</p>
            <p>Whether you are enjoying a simple meal or sharing food with family, discover flavours that bring the warmth of traditional cooking to your table.</p>
          </div>
          <Link to="/about" className="mt-8 inline-flex rounded-lg border-2 border-primary px-6 py-3 font-bold text-primary hover:bg-primary hover:text-primary-foreground">Read Our Story</Link>
        </div>
      </section>

      {/* Popular */}
      <section className="kolam-bg py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <SectionHeading eyebrow="Popular Picks" title="You May Also Love" />
          <div className="mt-12 grid grid-cols-1 gap-5 min-[420px]:grid-cols-2 lg:grid-cols-4">
            {pick(popularIds).map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </div>
      </section>

      {/* Enquiry CTA */}
      <section className="bg-primary py-16 text-primary-foreground">
        <div className="mx-auto flex max-w-5xl flex-col items-center gap-6 px-4 text-center sm:px-6">
          <h2 className="text-3xl font-bold sm:text-4xl">Craving the Taste of Home?</h2>
          <p className="max-w-2xl text-primary-foreground/85">Message us on WhatsApp to ask about prices, pack sizes, availability and ordering.</p>
          <a href={whatsappLink()} target="_blank" rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-lg bg-turmeric px-7 py-3.5 font-bold text-earth hover:bg-cream">
            <WhatsAppIcon className="h-5 w-5" /> Enquire on WhatsApp
          </a>
        </div>
      </section>

      {/* Social */}
      <section className="mx-auto max-w-3xl px-4 py-20 text-center sm:px-6">
        <SectionHeading title="Stay Connected with Palleturu Pachallu"
          subtitle="Follow our journey and discover more flavours, food inspiration, and updates from Palleturu Pachallu." />
        <div className="mt-8 flex justify-center"><SocialLinks tone="dark" /></div>
      </section>
    </>
  );
}
