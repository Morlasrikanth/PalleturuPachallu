import { createFileRoute, Link } from "@tanstack/react-router";
import kitchen from "@/assets/story-kitchen.jpg";
import avakaya from "@/assets/p-avakaya.jpg";
import snacks from "@/assets/cat-snacks.jpg";
import { PageHero } from "@/components/site/Layout";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Us — Palleturu Pachallu" },
      { name: "description", content: "Every jar carries the taste of home. The story behind Palleturu Pachallu." },
      { property: "og:title", content: "About Us — Palleturu Pachallu" },
      { property: "og:description", content: "Inspired by village kitchens and Amma Chethi Kammadhanam." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <>
      <PageHero eyebrow="Our Story" title="Every Jar Carries the Taste of Home." image={kitchen} />
      <section className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-20 sm:px-6 lg:grid-cols-2">
        <div className="space-y-5 text-lg leading-relaxed text-muted-foreground">
          <p className="font-display text-2xl text-earth">Palleturu Pachallu celebrates the flavours that make every Andhra meal special.</p>
          <p>Inspired by the warmth of village kitchens and the timeless goodness of <span className="font-bold text-primary">Amma Chethi Kammadhanam</span>, our collection brings together traditional pickles, spicy karam varieties, and beloved homemade snacks.</p>
          <p>From the bold flavour of avakaya to the comforting taste of traditional snacks, every category reflects our love for Andhra food culture.</p>
          <p>Our vision is to bring the authentic taste of Palleturu to families who cherish traditional flavours, one delicious bite at a time.</p>
          <Link to="/products" className="inline-flex rounded-lg bg-primary px-7 py-3.5 font-bold text-primary-foreground hover:bg-chilli">Discover Our Products</Link>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <img src={avakaya} alt="Avakaya mango pickle in a ceramic jar" loading="lazy" width={816} height={816} className="aspect-[3/4] rounded-xl object-cover shadow-soft" />
          <img src={snacks} alt="Traditional Andhra snacks on brass plates" loading="lazy" width={1024} height={1024} className="mt-10 aspect-[3/4] rounded-xl object-cover shadow-soft" />
        </div>
      </section>
      <section className="bg-primary py-16 text-center text-primary-foreground">
        <p className="font-telugu text-3xl font-bold sm:text-4xl">అమ్మచేతి కమ్మదనం</p>
        <p className="mt-3 font-display text-xl italic text-turmeric">A Touch of Unique Spices.</p>
      </section>
    </>
  );
}
