import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { MapPin, Menu, X } from "lucide-react";
import logo from "@/assets/logo.png.asset.json";
import { ADDRESS, MAPS_URL, SOCIAL, WHATSAPP_DISPLAY, categories, whatsappLink } from "@/lib/catalog";
import { FacebookIcon, InstagramIcon, WhatsAppIcon, YouTubeIcon } from "./Icons";

const nav = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About Us" },
  { to: "/products", label: "All Products" },
  { to: "/categories", label: "Categories" },
  { to: "/contact", label: "Contact Us" },
] as const;

export function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-cream/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-2 sm:px-6">
        <Link to="/" className="flex items-center gap-3" aria-label="Palleturu Pachallu home">
          <img src={logo.url} alt="Palleturu Pachallu logo" width={72} height={72} className="h-14 w-14 sm:h-[72px] sm:w-[72px]" />
          <span className="hidden flex-col leading-tight sm:flex">
            <span className="font-display text-xl font-bold text-primary">Palleturu Pachallu</span>
            <span className="text-xs tracking-wide text-leaf">Amma Chethi Kammadhanam</span>
          </span>
        </Link>
        <nav className="hidden items-center gap-7 lg:flex" aria-label="Main">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} activeOptions={{ exact: true }}
              className="text-sm font-semibold text-earth transition hover:text-primary data-[status=active]:text-primary">
              {n.label}
            </Link>
          ))}
          <a href={whatsappLink()} target="_blank" rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-bold text-primary-foreground hover:bg-chilli">
            <WhatsAppIcon className="h-4 w-4" /> Order Now
          </a>
        </nav>
        <button className="rounded-md p-2 text-earth lg:hidden" onClick={() => setOpen(!open)} aria-label="Toggle menu" aria-expanded={open}>
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>
      {open && (
        <nav className="border-t border-border bg-cream px-4 pb-4 lg:hidden" aria-label="Mobile">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} onClick={() => setOpen(false)} activeOptions={{ exact: true }}
              className="block border-b border-border py-3 font-semibold text-earth data-[status=active]:text-primary">
              {n.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}

export function SocialLinks({ tone = "light" }: { tone?: "light" | "dark" }) {
  const cls = tone === "light"
    ? "border-primary-foreground/30 text-primary-foreground hover:bg-turmeric hover:text-earth"
    : "border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground";
  const items = [
    { href: SOCIAL.instagram, label: "Instagram", Icon: InstagramIcon },
    { href: SOCIAL.facebook, label: "Facebook", Icon: FacebookIcon },
    { href: SOCIAL.youtube, label: "YouTube", Icon: YouTubeIcon },
    { href: whatsappLink(), label: "WhatsApp", Icon: WhatsAppIcon },
  ];
  return (
    <div className="flex gap-3">
      {items.map(({ href, label, Icon }) => (
        <a key={label} href={href} target="_blank" rel="noopener noreferrer" aria-label={label}
          className={`flex h-11 w-11 items-center justify-center rounded-full border transition ${cls}`}>
          <Icon className="h-5 w-5" />
        </a>
      ))}
    </div>
  );
}

export function Footer() {
  return (
    <footer className="bg-earth text-primary-foreground">
      <div className="motif-divider opacity-60" />
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <div className="flex items-center gap-3">
            <img src={logo.url} alt="" width={56} height={56} className="h-14 w-14" loading="lazy" />
            <div>
              <p className="font-display text-xl font-bold">Palleturu Pachallu</p>
              <p className="text-sm text-turmeric">Amma Chethi Kammadhanam</p>
            </div>
          </div>
          <p className="mt-4 text-sm italic text-primary-foreground/80">A Touch of Unique Spices.</p>
          <p className="mt-3 text-sm text-primary-foreground/70">Celebrating the authentic flavours of Andhra, one delicious bite at a time.</p>
        </div>
        <div>
          <h4 className="text-lg text-turmeric">Explore</h4>
          <ul className="mt-4 space-y-2 text-sm">
            {nav.map((n) => <li key={n.to}><Link to={n.to} className="text-primary-foreground/80 hover:text-turmeric">{n.label}</Link></li>)}
          </ul>
        </div>
        <div>
          <h4 className="text-lg text-turmeric">Categories</h4>
          <ul className="mt-4 space-y-2 text-sm">
            {categories.map((c) => (
              <li key={c.id}><Link to="/products" search={{ category: c.id }} className="text-primary-foreground/80 hover:text-turmeric">{c.short}</Link></li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="text-lg text-turmeric">Get in Touch</h4>
          <a href={MAPS_URL} target="_blank" rel="noopener noreferrer"
            className="group mt-4 flex items-start gap-2 text-sm leading-relaxed text-primary-foreground/85 hover:text-turmeric">
            <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-turmeric transition group-hover:scale-110" />
            <span>
              {ADDRESS.lines.map((line) => <span key={line} className="block">{line}</span>)}
              <span className="mt-1 block font-semibold text-turmeric underline decoration-dotted underline-offset-4">
                Open in Google Maps
              </span>
            </span>
          </a>
          <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="mt-4 flex items-center gap-2 text-sm text-primary-foreground/90 hover:text-turmeric">
            <WhatsAppIcon className="h-4 w-4" /> WhatsApp: {WHATSAPP_DISPLAY}
          </a>
          <div className="mt-5"><SocialLinks /></div>
        </div>
      </div>
      <div className="border-t border-primary-foreground/10 pt-5 pb-20">
        <div className="mx-auto flex max-w-7xl flex-col items-center gap-2 px-4 text-center text-xs text-primary-foreground/60 sm:flex-row sm:justify-between sm:px-6">
          <p>© 2026 Palleturu Pachallu. All Rights Reserved.</p>
          <p className="text-primary-foreground/70">
            Design &amp; Developed by <span className="font-semibold text-turmeric">Ugyan Tech Solutions</span>
          </p>
        </div>
      </div>
    </footer>
  );
}

export function FloatingWhatsApp() {
  return (
    <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" aria-label="Chat with us on WhatsApp"
      className="fade-up fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-whatsapp text-primary-foreground shadow-lift transition hover:scale-110">
      <WhatsAppIcon className="h-7 w-7" />
    </a>
  );
}

export function SectionHeading({ eyebrow, title, subtitle }: { eyebrow?: string; title: string; subtitle?: string }) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      {eyebrow && <p className="text-xs font-bold uppercase tracking-[0.25em] text-chilli">{eyebrow}</p>}
      <h2 className="mt-2 text-3xl font-bold text-earth sm:text-4xl">{title}</h2>
      <div className="motif-divider mx-auto mt-4 w-40" />
      {subtitle && <p className="mt-4 text-base leading-relaxed text-muted-foreground">{subtitle}</p>}
    </div>
  );
}

export function PageHero({ eyebrow, title, subtitle, image }: { eyebrow: string; title: string; subtitle?: ReactNode; image: string }) {
  return (
    <section className="relative overflow-hidden">
      <img src={image} alt="" className="absolute inset-0 h-full w-full object-cover" width={1920} height={1088} />
      <div className="bg-hero-overlay absolute inset-0" />
      <div className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 md:py-28">
        <div className="fade-up max-w-xl text-primary-foreground">
          <p className="text-xs font-bold uppercase tracking-[0.25em] text-turmeric">{eyebrow}</p>
          <h1 className="mt-3 text-4xl font-bold leading-tight sm:text-5xl">{title}</h1>
          {subtitle && <p className="mt-4 text-lg text-primary-foreground/85">{subtitle}</p>}
        </div>
      </div>
    </section>
  );
}
