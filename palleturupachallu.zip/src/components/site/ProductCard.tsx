import { categoryLabel, productMessage, whatsappLink, type Product } from "@/lib/catalog";
import { WhatsAppIcon } from "./Icons";

export function ProductCard({ product }: { product: Product }) {
  const isNonVeg = product.category === "nonveg";
  return (
    <article className="group flex h-full flex-col overflow-hidden rounded-xl border border-border bg-card shadow-soft transition duration-300 hover:-translate-y-1 hover:shadow-lift">
      <div className="relative aspect-square overflow-hidden bg-muted">
        <img
          src={product.image}
          alt={product.subtitle ?? product.name}
          loading="lazy"
          width={816}
          height={816}
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
        <span
          className={`absolute left-3 top-3 rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-wider ${
            isNonVeg ? "bg-primary text-primary-foreground" : "bg-cream/95 text-leaf"
          }`}
        >
          {isNonVeg ? "Non-Veg" : categoryLabel(product.category)}
        </span>
      </div>
      <div className="flex flex-1 flex-col p-4 sm:p-5">
        <h3 className={`text-lg leading-snug text-earth sm:text-xl ${product.telugu ? "font-telugu font-semibold" : ""}`}>
          {product.name}
        </h3>
        {product.subtitle && <p className="mt-0.5 text-xs font-semibold uppercase tracking-wider text-chilli">{product.subtitle}</p>}
        <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">{product.description}</p>
        <p className="mt-3 text-xs font-bold uppercase tracking-wider text-turmeric">Contact us for price</p>
        <a
          href={whatsappLink(productMessage(product.name))}
          target="_blank"
          rel="noopener noreferrer"
          aria-label={`Buy ${product.name} on WhatsApp`}
          className="mt-3 inline-flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground transition hover:bg-chilli"
        >
          <WhatsAppIcon className="h-4 w-4" /> Buy Now
        </a>
      </div>
    </article>
  );
}
